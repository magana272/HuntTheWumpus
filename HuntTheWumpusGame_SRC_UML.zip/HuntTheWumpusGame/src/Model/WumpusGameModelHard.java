package Model;

import java.util.ArrayList;
import java.util.List;
public class  WumpusGameModelHard extends WumpusGameModel {
    public WumpusGameModelHard(int numPits, int numBats, int numWumpus) {
        super(numPits, numBats, numWumpus);
    }
    

}
