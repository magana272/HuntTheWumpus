package Model.GameBoard;

public class Edge {
    private final int id;

    public Edge(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }
}