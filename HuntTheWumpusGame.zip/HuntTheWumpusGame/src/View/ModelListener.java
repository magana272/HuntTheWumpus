package View;

public interface ModelListener {
    void update();
    
}
