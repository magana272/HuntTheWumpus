import Controller.WumpusGameController;

public class Main {
    public static void main(String[] args) {
        WumpusGameController wumpusgame = new WumpusGameController();
        wumpusgame.startScreen();
    }
}